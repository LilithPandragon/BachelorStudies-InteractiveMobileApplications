package com.example.flavorfusion.model

class Recipe(recipeID: Int, recipeName: String, recipeDes: String) {

    var recipeID : Int? = recipeID
    var recipeName : String ? = recipeName
    var recipeDes: String? = recipeDes
}